﻿namespace Logshark.Plugins.$safeprojectname$.Model
{
    public class Widget
    {
        public string FooType { get; set; }
        public int FooRating { get; set; }
    }
}