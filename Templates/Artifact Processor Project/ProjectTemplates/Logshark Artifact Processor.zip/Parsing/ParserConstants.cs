﻿namespace Logshark.ArtifactProcessors.$safeprojectname$.Parsing
{
    /// <summary>
    /// Constants relating to log parsers.
    /// </summary>
    public static class ParserConstants
    {
        // The collection names for each log type.
        public static readonly string SampleCollectionName = "sample";
    }
}
