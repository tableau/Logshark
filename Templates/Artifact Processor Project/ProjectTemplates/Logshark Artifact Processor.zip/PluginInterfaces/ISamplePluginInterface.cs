﻿namespace Logshark.ArtifactProcessors.$safeprojectname$.PluginInterfaces
{
    public interface ISamplePluginInterface
    {
    }
}